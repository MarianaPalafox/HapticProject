/********************************************
*
*	Programa ejemplo, inicializaci�n del dispositivo h�ptico
*   y creaci�n de mundo virtual con respuesta din�mica
*	Taller de aplicaciones con h�pticos 
*	usando chai3d
*
*    Eusebio Ric�rdez V�zquez
*********************************************/
//===========================================================================

//---------------------------------------------------------------------------
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//---------------------------------------------------------------------------
#include "chai3d.h"
// Incluir la ruta de esta biblioteca
#include "CODE.h"		
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// DECLARACI�N DE CONSTANTES
//---------------------------------------------------------------------------

// La camara a trav�s de la cual observaremos el mundo
// initial size (width/height) in pixels of the display window
const int WINDOW_SIZE_W         = 512;
const int WINDOW_SIZE_H         = 512;

// mouse menu options (right button)
const int OPTION_FULLSCREEN     = 1;
const int OPTION_WINDOWDISPLAY  = 2;


//---------------------------------------------------------------------------
//Definici�n de variables globales
//---------------------------------------------------------------------------


// El mundo que contendr� todo
cWorld* world;

// La camara a trav�s de la cual observaremos el mundo
cCamera* camera;

// Fuente de luz
cLight *light;

// Ancho y alto de la pantalla gr�fica
int displayW  = 0;
int displayH  = 0;

// Manejador del dispositivo h�ptico
cHapticDeviceHandler *handler;

// Dispositivo h�ptico
cGenericHapticDevice* hapticDevice;


// Herramienta virtual
cGeneric3dofPointer* tool;

// radio del proxy
double proxyRadius;

// Dureza m�xima a utilizar 
double stiffnessMax;

// Variable de la simulaci�n
bool simulationRunning = false;

// Mundo din�mico
cODEWorld* ODEWorld;

// Objetos din�micos
cODEGenericBody* ODEBody0;
cODEGenericBody* ODEBody1;
cODEGenericBody* ODEBody2;

cODEGenericBody* ODEGPlane0;
cODEGenericBody* ODEGPlane1;
cODEGenericBody* ODEGPlane2;
cODEGenericBody* ODEGPlane3;
cODEGenericBody* ODEGPlane4;
cODEGenericBody* ODEGPlane5;


// Variable de control para el hilo h�ptico
bool simulationFinished = false;


//---------------------------------------------------------------------------
// PROTOTIPO DE FUNCIONES
//---------------------------------------------------------------------------


// funci�n de resize para OpenGL
void resizeWindow(int w, int h);

// Detecci�n de teclas 
void keySelect(unsigned char key, int x, int y);

// Menu para el mouse
void menuSelect(int value);

// Funci�n para terminar las ejecuciones antes de cerrar
void close(void);

// Rutina gr�fica principal
void updateGraphics(void);

// Rutina principal h�ptica
void updateHaptics(void);

// Cubo hecho con mallas
//void createCube(cMesh* a_mesh, double a_size);


int main(int argc, char* argv[])
{
    //-----------------------------------------------------------------------
    // INITIALIZACION
    //-----------------------------------------------------------------------

    printf ("\n");
    printf ("-----------------------------------\n");
    printf ("Programa ejemplo para demostrar uso de CHAID 3D\n");
    printf ("Mundo deformable\n");
	printf ("[1] - Habilita gravedad\n");
    printf ("[2] - Desabilita gravedad\n");
	printf ("[x] o [ESC]- termina la applicacion \n");
    printf ("-----------------------------------\n");
	printf ("\n\n");
   



    //-----------------------------------------------------------------------
    // 3D - SCENEGRAPH
    //-----------------------------------------------------------------------

  // Creaci�n y configutaci�n del mindo virtual
    world = new cWorld();

    // Elecci�n del color de fondo
    // el color se selecciona usando componentes (R,G,B) 
    world->setBackgroundColor(0.0, 0.0, 0.0);

    // Creacion y configuraci�n de la c�mara
    camera = new cCamera(world);
    world->addChild(camera);



    // posicion y orientaci�n de la camara
    camera->set( cVector3d (2.0, 0.0, 1.5),    // position (eye)
                 cVector3d (0.0, 0.0, 0.0),    // lookat position (target)
                 cVector3d (0.0, 0.0, 1.0));   // direcci�n del vector "up" 

    // Planos de corte "near y far" de la c�mara
    // lo que est� atras o adelante de estos planos no se visualizar�
    camera->setClippingPlanes(0.01, 10.0);

    // Habilitaci�n de transparencia
    camera->enableMultipassTransparency(true);


  // Creaci�n de una fuente de luz
    light = new cLight(world);
    camera->addChild(light);                   // Fijar la luz a la c�mara
    light->setEnabled(true);                   // Habilitar fuente de luz
    light->setPos(cVector3d( 2.0, 0.5, 1.0));  // Posici�n de la fuente de luz
    light->setDir(cVector3d(-2.0, 0.5, 1.0));  // Direcci�n del haz de luz
	light->m_ambient.set(0.6, 0.6, 0.6);	   // Configuraci�n de la iluminaci�n
    light->m_diffuse.set(0.8, 0.8, 0.8);
    light->m_specular.set(1.0, 1.0, 1.0);



 // Configuraci�n del dispositivo h�ptico y la esfera de exploraci�n h�ptica

	// Activaci�n del controlador del dispositivo h�ptico
	handler = new cHapticDeviceHandler();
	// Accede al primer dispositivo disponible

	if(handler->getDevice(hapticDevice, 0) < 0)
	{
		printf("Error: no hay dispositivo disponible");
		exit(1);
	}
	// Obtener la informaci�n del dispositivo conectado
	cHapticDeviceInfo info;
	if (hapticDevice != NULL)
	{
		hapticDevice->open();
		hapticDevice->initialize();
		info = hapticDevice->getSpecifications();
	}


    // Creaci�n de la herramienta de exploraci�n h�ptica
    tool = new cGeneric3dofPointer(world);
    world->addChild(tool);

    // conectar la herramienta al dispositivo h�ptico
    tool->setHapticDevice(hapticDevice);

    // inicializaci�n de la herramienta
    tool->start();

    // escala la herramienta en el mundo virtual
    tool->setWorkspaceRadius(1.3);

    // Radio de la herramienta de exploraci�n (gr�fico)
    tool->setRadius(0.02);

    // mostrar solo el proxy.
    tool->m_deviceSphere->setShowEnabled(false);

    // Radio del proxy.
    proxyRadius = 0.0;
    tool->m_proxyPointForceModel->setProxyRadius(proxyRadius);
	// habilitar ambos lados
    tool->m_proxyPointForceModel->m_collisionSettings.m_checkBothSidesOfTriangles = false;

	// Permite que los objetos de la escena sean din�micos, pueden hacer rotaciones y traslaciones
    // Si el mundo es est�tico, este par�metro sera "false"
    tool->m_proxyPointForceModel->m_useDynamicProxy = true;


    // Escala el mundo virtual con el tama�o f�sico del cursor h�ptico
    double workspaceScaleFactor = tool->getWorkspaceScaleFactor();

    // define y esscala el valor m�ximo de fuerza que puede usarse
    stiffnessMax = info.m_maxForceStiffness / workspaceScaleFactor;


    //-----------------------------------------------------------------------
    // Escena virtual
    //-----------------------------------------------------------------------

    // Instanciaci�n del mundo virtual din�mico
    ODEWorld = new cODEWorld(world);

    // Agrega el mindo din�mico al mundo
    world->addChild(ODEWorld);

    // configura la gravedad
    ODEWorld->setGravity(cVector3d(0.0, 0.0, -9.81));

    // Par�metros de amortiguamiento
    ODEWorld->setAngularDamping(0.00002);
    ODEWorld->setLinearDamping(0.00002);

    // creaci�n de tres objetos din�micos que se agregan al mundo
    ODEBody0 = new cODEGenericBody(ODEWorld);
    ODEBody1 = new cODEGenericBody(ODEWorld);
    ODEBody2 = new cODEGenericBody(ODEWorld);

	 // Creaci�n de 6 planos que limitan en mundo din�mico
    ODEGPlane0 = new cODEGenericBody(ODEWorld);
    ODEGPlane1 = new cODEGenericBody(ODEWorld);
    ODEGPlane2 = new cODEGenericBody(ODEWorld);
    ODEGPlane3 = new cODEGenericBody(ODEWorld);
    ODEGPlane4 = new cODEGenericBody(ODEWorld);
    ODEGPlane5 = new cODEGenericBody(ODEWorld);
    
	// creatci�n de 3 objetos de mallas
    cMesh* object0 = new cMesh(world);
    cMesh* object1 = new cMesh(world);
    cMesh* object2 = new cMesh(world);
	bool fileload;
    // Carga esfera 0
    fileload = object0->loadFromFile("../modelos/ball-1/ball-1.3ds");
    
    object0->scale(0.05);
    object0->createAABBCollisionDetector(proxyRadius, true, false);

    // Carga esfera 1
    fileload = object1->loadFromFile("../modelos/ball-2/ball-2.3ds");
    
    object1->scale(0.05);
    object1->createAABBCollisionDetector(proxyRadius, true, false);

    // Carga esfera 2
    fileload = object2->loadFromFile("../modelos/ball-3/ball-3.3ds");
    
    object2->scale(0.05);
    object2->createAABBCollisionDetector(proxyRadius, true, false);

    // define propiedades para cada esfera
    cMaterial mat;
    mat.setStiffness(0.5 * stiffnessMax);
    mat.setDynamicFriction(0.7);
    mat.setStaticFriction(1.0);
    object0->setMaterial(mat, true, true);
    object1->setMaterial(mat, true, true);
    object2->setMaterial(mat, true, true);

    // agrega los objetos al mundo din�mico
    ODEBody0->setImageModel(object0);
    ODEBody1->setImageModel(object1);
    ODEBody2->setImageModel(object2);

    // creaci�n del modelo dinamico en el ambiente ODE
    object0->computeBoundaryBox(true);
    double sphereRadius = 0.5 * (object0->getBoundaryMax().x - object0->getBoundaryMin().x);
    ODEBody0->createDynamicSphere(sphereRadius);
    ODEBody1->createDynamicSphere(sphereRadius);
    ODEBody2->createDynamicSphere(sphereRadius);

    // define la masa de cada esfera
    ODEBody0->setMass(0.05);
    ODEBody1->setMass(0.05);
    ODEBody2->setMass(0.05);

    // Posici�n inicial de las esferas
    cVector3d pos;
    pos = cVector3d(0.0,-0.6, -0.5);
    ODEBody0->setPosition(pos);
    pos = cVector3d(0.0, 0.6, -0.5);
    ODEBody1->setPosition(pos);
    pos = cVector3d(0.0, 0.0, -0.5);
    ODEBody2->setPosition(pos);

    // Creaci�n de las "paredes" del mundo virtual7*
   
    double size = 1.0;
    double groundLevel = -1.0;
    ODEGPlane0->createStaticPlane(cVector3d(0.0, 0.0,  2.0 *size), cVector3d(0.0, 0.0 ,-1.0));
    ODEGPlane1->createStaticPlane(cVector3d(0.0, 0.0, -1.0), cVector3d(0.0, 0.0 , 1.0));
    ODEGPlane2->createStaticPlane(cVector3d(0.0, size, 0.0), cVector3d(0.0,-1.0, 0.0));
    ODEGPlane3->createStaticPlane(cVector3d( 0.0,-size, 0.0), cVector3d(0.0, 1.0, 0.0));
    ODEGPlane4->createStaticPlane(cVector3d(size, 0.0, 0.0), cVector3d(groundLevel, 0.0, 0.0));
    ODEGPlane5->createStaticPlane(cVector3d(-0.8 * size, 0.0, 0.0), cVector3d(1.0, 0.0, 0.0));

	/*
    //////////////////////////////////////////////////////////////////////////
    // Reflexi�n -- Esta secci�n si se descomenta, crea reflexi�n en el piso -- 
    //////////////////////////////////////////////////////////////////////////

    // Se crea un objeto intermedio en donde se crea una copia 
    // local del objeto dentro del mundo
    cGenericObject* reflexion = new cGenericObject();

	// Este objeto se configura como una sombra sin interacci�n h�ptica ni detecci�n de colisiones 
    
    reflexion->setAsGhost(true);

    // Se agrega el objeto al mundo
    world->addChild(reflexion);

    // El objeto se dibuja solo en un lado no en amvbos
    object0->setUseCulling(false, true);
    object1->setUseCulling(false, true);
    object2->setUseCulling(false, true);

    // Se crea el efecto de simetr�a para corresponder a la sombra
    cMatrix3d rotRefexion;
    rotRefexion.set(1.0, 0.0, 0.0,
                    0.0, 1.0, 0.0,
                    0.0, 0.0, -1.0);
    reflexion->setRot(rotRefexion);
    reflexion->setPos(0.0, 0.0, 2.0 * groundLevel - 0.005);

    // se agregan los objetos tambi�n al mundo deformable
    reflexion->addChild(ODEWorld);
    reflexion->addChild(tool);
	*/
	
    //////////////////////////////////////////////////////////////////////////
    // Creci�n del piso
    //////////////////////////////////////////////////////////////////////////

    // Una malla que ser� el piso
    cMesh* ground = new cMesh(world);
    world->addChild(ground);

    // creaci�n de cuatro vertices
    double groundSizeX = 1.0;
    double groundSizeY = 1.5;

    int vertices0 = ground->newVertex(-groundSizeX, -groundSizeY, 0.0);
    int vertices1 = ground->newVertex( groundSizeX, -groundSizeY, 0.0);
    int vertices2 = ground->newVertex( groundSizeX,  groundSizeY, 0.0);
    int vertices3 = ground->newVertex(-groundSizeX,  groundSizeY, 0.0);

    // crear dos tri�ngulos 
    ground->newTriangle(vertices0, vertices1, vertices2);
    ground->newTriangle(vertices0, vertices2, vertices3);

    // calcula las normales
    ground->computeAllNormals();

    // posici�n de la malla 
    ground->setPos(0.0, 0.0, -1.0);

    // agrega textura a la malla
    cTexture2D* groundTexture = new cTexture2D();
    fileload = groundTexture->loadFromFile("../modelos/black-plastic.bmp");
   
   
    ground->setTexture(groundTexture);

    // acomoda la textura en la malla
    cVertex* v;
    v = ground->getVertex(0);
    v->setTexCoord(1,0);
    v = ground->getVertex(1);
    v->setTexCoord(1,1);
    v = ground->getVertex(2);
    v->setTexCoord(0,1);
    v = ground->getVertex(3);
    v->setTexCoord(0,0);
    ground->setUseTexture(true);

    // define propiedades del material y agragalo al piso
    cMaterial matGround;
    matGround.setStiffness(0.8 * stiffnessMax);
    matGround.setDynamicFriction(0.7);
    matGround.setStaticFriction(1.0);
    matGround.m_ambient.set(0.4, 0.4, 0.4);
    matGround.m_diffuse.set(0.5, 0.5, 0.5);
    matGround.m_specular.set(1.0, 1.0, 1.0);
    ground->setMaterial(matGround);

    // habilita y configura propiedades de transparencia
  //  ground->setTransparencyLevel(0.5);
  //  ground->setUseTransparency(true);

    //-----------------------------------------------------------------------
    // OPEN GL - WINDOW DISPLAY
    //-----------------------------------------------------------------------

 // inicializacion de  GLUT
    glutInit(&argc, argv);

    // obtenci�n de la resoluci�n actual de la pantala y 
	// ubicacion del gr�fico en el centro de la misma
    int screenW = glutGet(GLUT_SCREEN_WIDTH);
    int screenH = glutGet(GLUT_SCREEN_HEIGHT);
    int windowPosX = (screenW - WINDOW_SIZE_W) / 2;
    int windowPosY = (screenH - WINDOW_SIZE_H) / 2;

    // inicializacion de la ventana de OPENGL
    glutInitWindowPosition(windowPosX, windowPosY);
    glutInitWindowSize(WINDOW_SIZE_W, WINDOW_SIZE_H);
    glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
    glutCreateWindow(argv[0]);
    glutDisplayFunc(updateGraphics);
    glutKeyboardFunc(keySelect);
    glutReshapeFunc(resizeWindow);
    glutSetWindowTitle("AMBIENTE DIN�MICO");

    // creaci�n del menu del mouse (Bot�n derecho)
    glutCreateMenu(menuSelect);
    glutAddMenuEntry("full screen", OPTION_FULLSCREEN);
    glutAddMenuEntry("window display", OPTION_WINDOWDISPLAY);
    glutAttachMenu(GLUT_RIGHT_BUTTON);


    //-----------------------------------------------------------------------
    // Iniciar simulaci�n
    //-----------------------------------------------------------------------

    // inicio de la simulaci�n
    simulationRunning = true;

    // Creaci�n del hilo para la parte h�ptica
    cThread* hapticsThread = new cThread();
    hapticsThread->set(updateHaptics, CHAI_THREAD_PRIORITY_HAPTICS);

    // loop principal de GLUT
    glutMainLoop();

    // Verificar que todo este cerrado cuando se cierra la ventana grafica
    close();

    // salida
    return (0);
}

//---------------------------------------------------------------------------

void resizeWindow(int w, int h)
{
    // Redibuja la ventana gr�fica con el nuevo tama�o
    displayW = w;
    displayH = h;
    glViewport(0, 0, displayW, displayH);
}

void keySelect(unsigned char key, int x, int y)
{
    if ((key == 27) || (key == 'x'))
    {
        // verifica que todo este cerrado
        close();

        // termina la aplicacion
        exit(0);
    }

	
    // opcion 1:
  
    if (key == '1')
    {
        // Habilita gravedad
        ODEWorld->setGravity(cVector3d(0.0, 0.0, -9.81));
    }

    // opci�n 2:
    if (key == '2')
    {
        // desabilita gravedad
        ODEWorld->setGravity(cVector3d(0.0, 0.0, 0.0));
    }
}

//---------------------------------------------------------------------------

void menuSelect(int value)
{
    switch (value)
    {
        // Pantalla completa
        case OPTION_FULLSCREEN:
            glutFullScreen();
            break;

        // tama�o original
        case OPTION_WINDOWDISPLAY:
            glutReshapeWindow(WINDOW_SIZE_W, WINDOW_SIZE_H);
            break;
    }
}

//---------------------------------------------------------------------------


void close(void)
{
    // detener la simulacion, esta variable controla el hilo haptico
    simulationRunning = false;

    // espera 100 ms para asegurarse que el hilo haptico se cerr�
    while (!simulationFinished) { cSleepMs(100); }

    // detener el dispositivo haptico
    hapticDevice->close();
}

//---------------------------------------------------------------------------

void updateGraphics(void)
{
     // trazar (render) el mundo
    camera->renderView(displayW, displayH);

    // Intercambio de buffers
    glutSwapBuffers();

   // verifica errores de glut
    GLenum err;
    err = glGetError();
    if (err != GL_NO_ERROR) printf("Error:  %s\n", gluErrorString(err));

   // Dibujar el mundo
    if (simulationRunning)
    {
        glutPostRedisplay();
    }
}

//---------------------------------------------------------------------------

void updateHaptics(void)
{
    // inicializa reloj
    cPrecisionClock simClock;
    simClock.start(true);

    // loop principal del h�ptico
    while(simulationRunning)
    {
        // Calcula las referencias de los objetos en el mundo
        world->computeGlobalPositions(true);

        // actualiza la posici�n y orientaci�n de la herramienta
        tool->updatePose();

        // calcula las fuerzas
        tool->computeInteractionForces();

        // Verifica si la herramienta est� tocando un objeto
        cGenericObject* object = tool->m_proxyPointForceModel->m_contactPoint0->m_object;

      
		 if (object != NULL)
            {
                // Verifica si el objeto est� sujeto a alg�n otro
                cGenericType* externalParent = object->getExternalParent();
                cODEGenericBody* ODEobject = dynamic_cast<cODEGenericBody*>(externalParent);
                if (ODEobject != NULL)
                {
                    // Obtener la posici�n de la herramienta
                    cVector3d pos = tool->m_proxyPointForceModel->m_contactPoint0->m_globalPos;

             
                    // Recupera la fuerza de interacci�n de la herramienta
                    cVector3d force = tool->m_lastComputedGlobalForce;

                    // aplica la fuerza al objeto din�mico
                    cVector3d tmpfrc = cNegate(force);
                    ODEobject->addGlobalForceAtGlobalPos(tmpfrc, pos);
                }
		 }
        // env�a fuerza el dispositivo h�ptico
		tool->applyForces();

        // Calcula el siguiente intervalo de simulaci�n
        double time = simClock.getCurrentTimeSeconds();
        double nextSimInterval = cClamp(time, 0.00001, 0.001);

        // reinicia el reloj
        simClock.reset();
        simClock.start();

        // actualiza el mundo din�mico
        ODEWorld->updateDynamics(nextSimInterval);
    }
    
    // fin del hilo h�ptico
    simulationFinished = true;
}


